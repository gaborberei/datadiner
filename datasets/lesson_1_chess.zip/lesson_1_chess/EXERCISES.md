# Retention exercises — online chess platform, 2024

The data is a full year of play on an online chess platform. One row means 
**this player played at least one rated game on this day** — the log is *daily*, and a player has no row for a day they didn't play. `event_count` is how many games they played that day.

Two attributes come from the signup record and never change: `platform`
(`desktop` / `mobile`) and `acquisition_channel` (`organic` / `paid` / `social`),
so grouping by either splits **players**, not events. There are no ratings, no
session lengths, no country or app-version columns.

**Data:** `activity.csv`, in this folder.
**Config:** `analysis.yaml`, in this folder — the decisions already made
(core action, segments, weekly periods starting Monday). Read it first.

## How to work

Run `/retention-analysis` and let it drive, or do it yourself:

```python
from retentionkit import load_activity, quality_report, format_quality_report
from retentionkit.config import load_config
from retentionkit.report import run_report

cfg = load_config("datasets/lesson_1_chess/activity.csv")
df  = load_activity(cfg["file"])
run_report(df, dataset="lesson_1_chess", config=cfg)
```

That writes `output/lesson_1_chess/<timestamp>/` — `report.md`, `charts/` and
`data/`. Un-segmented figures land in `charts/overall/`, segmented ones in
`charts/<segment_col>/`. Every figure has a CSV twin in `data/`, so you can check
any number rather than squinting at a picture.

Answer in your own words. For every claim, say **which metric you judged it by
and why that metric** — picking the wrong measure is the most common way to get
one of these confidently wrong.

---

## Part 1 — Orientation

**1.** Load the file and run `quality_report()`. Report the rows, distinct
players, date span, panel density, and the natural frequency. Then explain: the
panel is only ~18% dense — why is the other 82% **not** missing data, and what
would break if you treated it as missing?

**2.** Generate the run. List what's in the output folder and say which subfolder
un-segmented charts go to. Then: the config sets
`core_action: game_played`, so every view is filtered to that event. Prove it
changes nothing on this dataset, and name the one thing you could have checked
*first* to know that in advance.

---

## Part 2 — Reading the views

**3.** Two cadence numbers disagree, and both are correct. The usage-frequency
histogram puts the median player at **1.7 active days per month**. The natural
frequency says the median **return gap is 4 days**. Reconcile them — what
population is each one measuring? Then say which of the two should decide whether
retention is computed weekly or monthly, and why.

**4.** On the retention curve: find the single steepest drop and give its size in
percentage points. Then find where the curve stops falling and what level it
settles at. Say what that plateau tells you about the product that the steep drop
does not — and what the curve would have to look like instead for you to say
there is no durable core.

---

## Part 3 — What happened in 2024

**5.** How would you evaluate the growth of the company? Is it driven by marketing or by organic growth? Which figure(s) should you look at to answer this question?

**6.** The company ran a new marketing campaign at the end of February / March. Then cut back the spending in April. How would you evaluate these shocks? 

**7.** The company introduced a new onboarding flow from the end of May until July, then switched back to the old one because the CEO didn't like it. How would you evaluate it? Would it be worth keeping?

**8.** One calendar week is bad for every cohort at once, regardless of how long
those players had been around. Find it and quantify the drop.
Then test the claim *"it fixed itself — actives were back inside a month, so there was no lasting damage."* State precisely what recovered and what didn't. What could have caused this issue?

---

## Part 4 — Decisions

**9.** What would you recommend the marketing department do next?
Which platform and acquisition channel should they focus on? What other information do you need
to quantify the ROI on spending, assuming there is a paid tier for the platform?

**10.** The Head of Product is planning the new roadmap and asks for your data-driven recommendations. The budget is tight, and she doesn't know whether the company should focus on onboarding, develop a new feature (an AI analyst for analysing games), or start a new resurrection campaign.

---

## Reference

### The metrics

If your numbers look off, check these first.

- **Week** — starts **Monday**. Set in `analysis.yaml`; the package translates it
  (pandas' own `W-XXX` aliases name the day a week *ends*, which is a classic
  off-by-one).
- **Active** — a player is active in a week if they played on **any day** of it.
  It is a presence flag: one game on one day counts the same as fifty games
  across seven.
- **WAU** — distinct players active in the week.
- **Cohort** — signup week = the week a player first appears. Identifiers are
  never reissued, so a player's earliest week is their signup week.
- **New / Retained / Resurrected / At-Risk / Churned**, for week *W*: *new* =
  first appearance is *W* · *retained* = active in *W* and *W−1* · *resurrected*
  = active in *W* after being At-Risk or Churned · *At-Risk* = active in *W−1*,
  absent in *W* · *churned* = a **second** consecutive absence. Churn is not
  final; a churned player who returns is Resurrected.
- **Quick ratio** — (new + resurrected) / churned. Above 1 the base grows, below
  1 it shrinks.

### The charts

| Chart | X axis | Y axis | One point/cell means | Healthy looks like |
|---|---|---|---|---|
| **Usage frequency** | avg active days per month | players | this many players keep this cadence | mass at the cadence the product is designed for. A spike at 1 with a thin tail is a trial-and-leave product. |
| **Retention curve** | weeks since signup | % of the cohort still active | at age *N*, this share of signups is still playing | falls steeply, then **flattens** onto a plateau well above zero — a durable core. Still heading to zero at the right edge means no core. |
| **Cohort heatmap** | weeks since signup | one row per signup cohort (oldest at top) | of the cohort in this row, the % still active at this age | rows that look alike, fading gently rightward. Check the `Signups` column first — a bright cell on a tiny cohort is noise. |
| **Lifecycle bars** | calendar week | players; new/retained/resurrected up, at-risk/churned down | how the active base was composed that week | the *retained* band growing as a share of the bar. If growth is all new + resurrected while retained stays flat, you are refilling a leaky bucket. |
| **Quick ratio line** | calendar week | (new + resurrected) / churned | players gained for each one lost | steady and comfortably above 1. The 1.0 line is break-even. |

Three directions on the heatmap, because they mean different things. A **bad
row** — one cohort worse than its neighbours at every age — points at *who you
acquired* that week. A **diagonal** — one calendar period bad across every cohort
regardless of age — points at something that hit everyone at once. A **column** —
one age bad across all cohorts — points at a tenure milestone.
